# EL IMAGE DEFECT DETECTION > 2024-04-24 4:19pm
https://universe.roboflow.com/el-image-defect-detection/el-image-defect-detection

Provided by a Roboflow user
License: CC BY 4.0

